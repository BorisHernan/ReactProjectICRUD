﻿namespace ReactVentas.Models.DTO
{
    public class DtoDetalleVenta
    {
        public string? Producto { get; set; }
        public string? Precio { get; set; }

        public string? Cantidad { get; set; }

        public string? Total { get; set; }
    }
}
